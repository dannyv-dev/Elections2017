# Elections2017
Small Browser Javascript App to facilitate processing of Elections2017-Honduras data.

Applicacion creada por : coder4humanity

Con mucho orgullo para mi pais, HONDURAS!